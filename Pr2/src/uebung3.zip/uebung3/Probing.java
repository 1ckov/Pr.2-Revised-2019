package uebung3;

public interface Probing {
    public int nextNum();
    public int getNum();
    public void startProbing();
}

